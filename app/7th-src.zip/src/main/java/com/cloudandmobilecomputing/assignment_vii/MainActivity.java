package com.cloudandmobilecomputing.assignment_vii;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    // Declare UI components
    private EditText title, place, participants, dateTime;
    private Button submitButton, searchButton, updateButton;

    // Static list to store meetings (you can consider using a database or SharedPreferences)
    private static ArrayList<Meeting> meetingList = new ArrayList<>();

    private static final int REQUEST_CODE_UPDATE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        title = findViewById(R.id.meetingTitle);
        place = findViewById(R.id.meetingPlace);
        participants = findViewById(R.id.meetingParticipants);
        dateTime = findViewById(R.id.meetingDateTime);
        submitButton = findViewById(R.id.submitButton);
        searchButton = findViewById(R.id.searchButton);
        updateButton = findViewById(R.id.updateButton);

        // Submit button click listener: Create a meeting and store it in the list
        submitButton.setOnClickListener(v -> {
            String meetingTitle = title.getText().toString();
            String meetingPlace = place.getText().toString();
            String meetingParticipants = participants.getText().toString();
            String meetingDateTime = dateTime.getText().toString();

            // Create a Meeting object with input data
            Meeting meeting = new Meeting(meetingTitle, meetingPlace, meetingParticipants, meetingDateTime);

            // Add the meeting to the meeting list
            meetingList.add(meeting);

            // Pass the meeting summary to the next activity
            Intent intent = new Intent(MainActivity.this, MeetingSummaryActivity.class);
            intent.putExtra("meeting_data", meeting.getMeetingSummary());
            startActivity(intent);
        });

        // Search button click listener: Pass the list of meetings to SearchMeetingActivity
        searchButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SearchMeetingActivity.class);
            // Pass the list of meetings to the search activity
            intent.putExtra("meetingList", meetingList);
            startActivity(intent);
        });

        // Update button click listener: Navigate to UpdateMeetingActivity
        updateButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, UpdateMeetingActivity.class);
            intent.putExtra("meetingList", meetingList);
            startActivityForResult(intent, REQUEST_CODE_UPDATE);

        });
    }

    // Method to retrieve the list of meetings (if needed elsewhere in the app)
    public static ArrayList<Meeting> getMeetingList() {
        return meetingList;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_UPDATE && resultCode == RESULT_OK) {
            // Retrieve updated list
            meetingList = (ArrayList<Meeting>) data.getSerializableExtra("updatedMeetingList");
            // Refresh display or notify adapter if using RecyclerView/ListView
        }
    }

}
